import math

def tr_function(pressure,zenith_angle):
    # (pressure) Atmospheric Pressure in Kilopascal
    m_a =  m_a_function(pressure, zenith_angle)
    #print(f'Ma: {m_a}')
    t_r = math.exp((-0.0903)*(m_a**0.84)*(1.0+m_a-(m_a**1.01)))
    #print(f'e^x, x: {(-0.0903)*(m_a**0.84)*(1.0+m_a-(m_a**1.01))}')
    #print(f'tr: {t_r}')
    return t_r

def t_aer_function(pressure, zenith_angle):
    # (pressure) Atmospheric Pressure in Kilopascal
    m_a =  m_a_function(pressure, zenith_angle)

    t_aer_p38 = t_aer_p_funtion(38)
    t_aer_p50 = t_aer_p_funtion(50)
    #print(f'Taer-0.38um: {t_aer_p38}, Taer-0.50: {t_aer_p50}')
    
    k_a = (0.2758*(t_aer_p38)) + (0.35*(t_aer_p50))
    #print(f'Ka: {k_a}')

    t_aer = math.exp((-(k_a)**0.873)*(1.0+k_a-(k_a**0.7088))*(m_a**0.9108))
    #print(f'taer: {t_aer}')
    return t_aer

def t_aera_function(pressure, zenith_angle, t_aer):
    #(pressure) Atmospheric Pressure in Kilopascal
    m_a =  m_a_function(pressure, zenith_angle)
    ssa = 1.0

    t_aera = 1.0-(1.0-(ssa))*((1.0)-(m_a)+(m_a**1.06))*(1.0-(t_aer))
    #print(f'taera: {t_aera}')
    return t_aera

def t_w_function(zenith_angle):
    w = 1
    m_r = 1/(abs(math.cos(Deg2Rad(zenith_angle))))
    u1 = (w)*(m_r)
    alpha_w = 2.4959*(u1)*(((1.0+79.034*(u1))**0.6828) + 6.385*(u1))**(-1)
    t_w = 1 - alpha_w
    #print(f'tw: {t_w}')
    return t_w

def  t_o_function(zenith_angle):
    l = 0.3
    m_r = 1/(abs(math.cos(Deg2Rad(zenith_angle))))
    u3 = (l)*(m_r)
    alpha_o = 0.1611*(u3)*(1.0+139.48*(u3))**(-0.3035)
    t_o = 1 - alpha_o
    #print(f'to: {t_o}')
    return t_o

def t_g_function(pressure, zenith_angle):
    m_a = m_a_function(pressure, zenith_angle)
    t_g = math.exp(-0.01278*((m_a))**0.26)
    #print(f'tg: {t_g}')
    return t_g

def m_a_function(pressure, zenith_angle):
    # Relative Air Mass, zenith angle in radian
    m_r = 1/(abs(math.cos(Deg2Rad(zenith_angle))))
    #print(f'Mr: {m_r}')
    # (pressure) Atmospheric Pressure in Kilopascal
    m_a =  m_r * (pressure/101.325)
    #print(f'Ma: {m_a}')
    return m_a

def t_aer_p_funtion(a_lambda):
    # Angstrom's Turbidity Coefficient at Khonkaen is 0.138 (mean)
    beta = 0.138
    # Angstrom's Wavelenght Exponent is 1.3 (mean)
    alpha = 1.3
    t_aer_p = (beta)*(a_lambda**(-alpha))
    #print(f'taer_p: {t_aer_p}')
    return t_aer_p

def Deg2Rad(deg):
    return deg * (math.pi / 180)
    
def Rad2Deg(rad):
    return rad * (180 / math.pi)

def main():

    pressure = 108
    zenith_angle = 39.55526311
    t_r = tr_function(pressure, zenith_angle)
    t_aer = t_aer_function(pressure, zenith_angle)
    t_o = t_o_function(zenith_angle)
    t_w = t_w_function(zenith_angle)
    t_g = t_g_function(pressure, zenith_angle)

    t = t_r * t_aer * t_o * t_w * t_g
    #print(f't: {t}')

#main()
