import math
import numpy as np

import HourAngleCal

def zenith_angle_function(dDelta, lat, hra):
    theta_z = Rad2Deg(math.acos(math.sin(Deg2Rad(dDelta))*math.sin(Deg2Rad(lat)) + math.cos(Deg2Rad(dDelta))*math.cos(Deg2Rad(lat))*math.cos(Deg2Rad(hra))))
    print(f'Zenith1 Acos: {math.sin(Deg2Rad(dDelta))*math.sin(Deg2Rad(lat)) + math.cos(Deg2Rad(dDelta))*math.cos(Deg2Rad(lat))*math.cos(Deg2Rad(hra))}')
    print(f'Zenith Angle1: {theta_z}')
    return theta_z

def zenith(dn,lat,lon,LST,minute,sec): #dn:julian day
    T=2*np.pi*(dn-1)/365
    dec=(0.006918-(0.399912*np.cos(T))+(0.070257*np.sin(T))-(0.006758*np.cos(2*T))+(0.000907*np.sin(2*T))-(0.002697*np.cos(3*T))+(0.00148*np.sin(3*T)))*(180/np.pi)
    print(f'Zenith2 Declination :{dec}')
    Et=229.18*(0.000075+(0.001868*np.cos(T))-(0.032077*np.sin(T))-(0.014615*np.cos(2*T))-(0.04089*np.sin(2*T)))
    ST=(((((sec/60)+minute)/60)+LST)+(4*(-105-(-lon))/60)+(Et/60))
    w=15*(12-ST)
    print(f'Zenith2 HRA :{w}')
    sza=np.arccos(np.sin(lat*np.pi/180)*np.sin(dec*np.pi/180)+np.cos(lat*np.pi/180)*np.cos(dec*np.pi/180)*np.cos(w*np.pi/180))*180/np.pi
    print(f'Zenith2 Acos: {(np.sin(lat*np.pi/180)*np.sin(dec*np.pi/180)+np.cos(lat*np.pi/180)*np.cos(dec*np.pi/180)*np.cos(w*np.pi/180))}')
    print(f'Zenith Angle2: {sza}')
    return sza

def Deg2Rad(deg):
    return deg * (math.pi / 180)
    
def Rad2Deg(rad):
    return rad * (180 / math.pi)

def main():
    day = 1
    time = 6
    minute = 0
    sec = 0
    long = 103.5
    lat = 16.4425
    dDelta = -23.01163673
    TZ = 7.0
    hra = HourAngleCal.solarHourAngle_function(day, time, long, TZ)
    print(f'Zenith1 HRA: {hra}')
    zenith_angle_function(dDelta, lat, hra)
    zenith(day, lat, long, time, minute, sec)

main()