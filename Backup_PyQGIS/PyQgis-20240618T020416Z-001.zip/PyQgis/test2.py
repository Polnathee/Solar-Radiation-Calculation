import math
import numpy as np

a = -0.1445072368087148
d =  -0.1451412961789641
b = math.acos(a)
c = np.arccos(a)

e = 0.44257877187579*2
print(e)
print(f'b: {b}, c: {c}')